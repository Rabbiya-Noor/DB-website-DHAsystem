from django.apps import AppConfig


class EvalappConfig(AppConfig):
    name = 'evalApp'
