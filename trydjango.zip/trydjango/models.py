# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Adha(models.Model):
    adha_id = models.IntegerField(db_column='ADHA_ID', primary_key=True)  # Field name made lowercase.
    login_password = models.CharField(max_length=20, blank=True, null=True)
    username = models.CharField(max_length=20, blank=True, null=True)
    starting_date = models.DateField(blank=True, null=True)
    ending_date = models.DateField(blank=True, null=True)
    adha_rank = models.CharField(db_column='ADHA_rank', max_length=20, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'adha'


class Clients(models.Model):
    client_id = models.IntegerField(db_column='client_ID', primary_key=True)  # Field name made lowercase.
    login_password = models.CharField(max_length=20, blank=True, null=True)
    username = models.CharField(max_length=20, blank=True, null=True)
    user_rank = models.CharField(max_length=20, blank=True, null=True)
    previous_employ = models.IntegerField(blank=True, null=True)
    adha = models.ForeignKey(Adha, models.DO_NOTHING, db_column='ADHA_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'clients'


class Director(models.Model):
    branch = models.CharField(max_length=20, blank=True, null=True)
    director_rank = models.CharField(max_length=20, blank=True, null=True)
    adha = models.ForeignKey(Adha, models.DO_NOTHING, db_column='ADHA_ID', blank=True, null=True)  # Field name made lowercase.
    dir_id = models.IntegerField(db_column='dir_ID', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'director'


class Employees(models.Model):
    emp_id = models.IntegerField(db_column='emp_ID', primary_key=True)  # Field name made lowercase.
    branch = models.CharField(max_length=20, blank=True, null=True)
    typeemp = models.CharField(max_length=20, blank=True, null=True)
    position = models.CharField(max_length=20, blank=True, null=True)
    duration = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)
    alloted_plot_no = models.DecimalField(max_digits=5, decimal_places=0, blank=True, null=True)
    dir = models.ForeignKey(Director, models.DO_NOTHING, db_column='dir_ID', blank=True, null=True)  # Field name made lowercase.
    client = models.ForeignKey(Clients, models.DO_NOTHING, db_column='client_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'employees'


class Plots(models.Model):
    phase_no = models.CharField(primary_key=True, max_length=20)
    sector = models.CharField(max_length=20)
    street = models.CharField(max_length=20)
    size = models.CharField(max_length=20, blank=True, null=True)
    client = models.ForeignKey(Clients, models.DO_NOTHING, db_column='client_ID', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'plots'
        unique_together = (('phase_no', 'sector', 'street'),)
