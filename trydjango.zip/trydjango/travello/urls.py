from django.urls import path

from . import views

urlpatterns = [
    path('',views.home,  name = 'home'),
    path('login',views.login,  name = 'login'),
    path('admin_login',views.admin_login,  name = 'admin_login'),
    path('login_option',views.login_option,  name = 'login_option'),
    path('register',views.register,  name = 'register'),
    path('home',views.home,  name = 'home'),
    path('user',views.user,  name = 'user'),
    path('admin_again',views.admin_again,  name = 'admin_again')
]
