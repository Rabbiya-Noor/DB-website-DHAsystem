from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Plots
from .models import Clients
from .models import Employees
from .models import Director
from django.contrib.auth.models import User, auth

# Create your views here.
def home(request):
   return render(request, 'index.html')

def login(request):
   clients = Clients.objects.all()
   return render(request, 'login.html', {'clients':clients})

def admin_login(request):
   clients = Clients.objects.all()
   return render(request, 'admin_login.html', {'clients':clients})

def login_option(request):
   clients = Clients.objects.all()
   return render(request, 'login_option.html')

def register(request):

   if (request.method != 'GET'):
      print('user created')
      firstname = request.POST['firstname']
      lastname = request.POST['lastname']
      username = request.POST['username']
      email = request.POST['email']
      password1 = request.POST['password1']
      password2 = request.POST['password2']
      user = User.objects.create_user(username = username, password = password1, email = email, first_name = firstname, last_name = lastname)
      user.save();
      return redirect('/')
   else:
      print('user created')
      return render(request, 'register.html')

def user(request):
   plots = Plots.objects.all()
   return render(request, 'user.html', {'plots':plots})

def admin_again(request):
   plots = Plots.objects.all()
   clients = Clients.objects.all()
   employees = Employees.objects.all()
   directors = Director.objects.all()
   return render(request, 'admin_again.html', {'plots':plots,'clients':clients, 'employees':employees,'directors':directors})